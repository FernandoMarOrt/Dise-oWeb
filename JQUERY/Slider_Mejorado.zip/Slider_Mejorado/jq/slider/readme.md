Unslider
========

[![Join the chat at https://gitter.im/idiot/unslider](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/idiot/unslider?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

The easiest way to get a simple slider up and running in seconds. All you need
is some valid markup, jQuery and some extra CSS, and Unslider can do the rest.

Check the docs out: http://unslider.com

Licensed under the [WTFPL](http://www.wtfpl.net).